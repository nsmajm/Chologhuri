@extends('Layout.HomeLayout')

@section('content')
   This is about page
@endsection