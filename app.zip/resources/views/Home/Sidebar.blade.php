<section id="sidebar">
    <div class="sidebar-title">
        <h5>Categories</h5>
    </div>
    <ul class="sidebar-item">
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="#">Home</a></li>

    </ul>
</section>